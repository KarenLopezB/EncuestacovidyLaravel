<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CapturaEncuesta extends Model
{
    protected $table = "capturas_encuesta";
}
