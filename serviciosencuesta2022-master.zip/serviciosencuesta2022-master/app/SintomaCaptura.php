<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SintomaCaptura extends Model
{
    protected $table = "sintomas_captura";
}
